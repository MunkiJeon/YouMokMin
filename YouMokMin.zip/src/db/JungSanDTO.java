package db;

public class JungSanDTO {

	public int plus;
	public int minus;
	public int realGain;

}
