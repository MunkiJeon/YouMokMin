package db;

public class SesinDTO {

	public Integer id;
	public Integer locker;
	public Integer password;
	public String menu;

}