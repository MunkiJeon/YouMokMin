package db;

public class BarberDTO {

	public Integer id;
	public Integer locker;
	public Integer password;
	public String menu;

}